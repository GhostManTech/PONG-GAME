try:
	import pygame, os, random, platform, time
	from pygame.locals import *
except Exception as error:print("[ERROR] => %s" % error)
else:
	# CONFIGURATION
	pygame.init()
	WIDTH, HEIGHT, WIDTH_SCREEN, HEIGHT_SCREEN = 1280, 720, pygame.display.Info().current_w, pygame.display.Info().current_h
	X, Y = (WIDTH_SCREEN - WIDTH)//2, (HEIGHT_SCREEN - HEIGHT)//2 
	pygame.display.set_caption("PONG GAME BY GhostManTech")
	if platform.system() == "Windows":
		pygame.display.set_icon(pygame.image.load("LIB/IMAGES/icon.png"))
	os.environ["SDL_VIDEO_WINDOW_POS"] = "%d,%d" % (X, Y)
	area = pygame.display.set_mode((WIDTH, HEIGHT))
	pygame.mouse.set_cursor(*pygame.cursors.broken_x)

	# GAME CONSTANTS
	CHOICES = [-1, 1]
	RED, WHITE, BLACK  = (255, 0, 0), (255, 255, 255), (0, 0, 0)
	BACKGROUND = pygame.image.load("LIB/IMAGES/background.jpg")
	PADDLE_X_INITIAL = [50, (HEIGHT-200)//2, 25, 200]
	PADDLE_Y_INITIAL = [WIDTH-75, (HEIGHT-200)//2, 25, 200]
	RADIUS = 10
	SPEED_PADDLE = 10
	SPACE = 50
	SPEED_BALL = 5

	# GAME VARIABLES
	number_of_exchanges = 0
	font = pygame.font.SysFont("Verdana", 25)
	clock = pygame.time.Clock()
	paddle_1, paddle_2 = list(PADDLE_X_INITIAL), list(PADDLE_Y_INITIAL)
	ball = [WIDTH//2, HEIGHT//2]
	ball_x, ball_y = random.choice(CHOICES), random.choice(CHOICES)
	player_1, player_2 = 0, 0

	# MOVES OF PADDLES
	def move():
		global paddle_1, paddle_2
		key = pygame.key.get_pressed()
		if key[pygame.K_w]:
			if paddle_1[1] - SPEED_PADDLE < 0:
				paddle_1[1] = 0
			else:
				paddle_1[1] -= SPEED_PADDLE
		if key[pygame.K_s]:
			if paddle_1[1] + paddle_1[3] + SPEED_PADDLE > HEIGHT:
				paddle_1[1] = HEIGHT-paddle_1[3]
			else:
				paddle_1[1] += SPEED_PADDLE
		if key[pygame.K_UP]:
			if paddle_2[1] - SPEED_PADDLE < 0:
				paddle_2[1] = 0
			else:
				paddle_2[1] -= SPEED_PADDLE
		if key[pygame.K_DOWN]:
			if paddle_2[1] + paddle_2[3] + SPEED_PADDLE > HEIGHT:
				paddle_2[1] = HEIGHT-paddle_2[3]
			else:paddle_2[1] += SPEED_PADDLE

	# GAMEPLAY AND BALL COLLISIONS
	def gameplay():
		global paddle_1, paddle_2, player_1, player_2, ball_x, ball_y, ball, number_of_exchanges
		if ball[0] + RADIUS == paddle_2[0] and paddle_2[1] <= ball[1] <= paddle_2[1]+paddle_2[3]:
			ball_x *= -1
			number_of_exchanges += 1
			if number_of_exchanges % 2 == 0:
				if paddle_1[3] - 10 < 50 and paddle_2[3] - 10 < 50:paddle_1[3], paddle_2[3] = 50, 50
				else:paddle_1[3], paddle_2[3] = paddle_1[3] - 10, paddle_2[3] - 10
		if ball[0] - RADIUS == paddle_1[0]+paddle_1[2] and paddle_1[1] <= ball[1] <= paddle_1[1]+paddle_1[3]:
			ball_x *= -1
			number_of_exchanges += 1
			if number_of_exchanges % 2 == 0:
				if paddle_1[3] - 10 < 50 and paddle_2[3] - 10 < 50:paddle_1[3], paddle_2[3] = 50, 50
				else:paddle_1[3], paddle_2[3] = paddle_1[3] - 10, paddle_2[3] - 10
		if ball[1] - RADIUS == 0 and ball[0] <= WIDTH - SPACE - paddle_2[2] and ball[0] >= SPACE + paddle_1[2]:
			ball_y *= -1
		if ball[1] + RADIUS == HEIGHT and ball[0] <= WIDTH - SPACE -paddle_2[2] and ball[0] >= SPACE + paddle_1[2]:
			ball_y *= -1
		if ball[0] + RADIUS == WIDTH:
			number_of_exchanges = 0
			player_1 += 1
			ball = [WIDTH//2, HEIGHT//2]
			ball_x, ball_y = CHOICES[0], random.choice(CHOICES)
			paddle_1, paddle_2 = list(PADDLE_X_INITIAL), list(PADDLE_Y_INITIAL)
		if ball[0] == 0:
			number_of_exchanges = 0
			player_2 += 1
			ball = [WIDTH//2, HEIGHT//2]
			ball_x, ball_y = CHOICES[1], random.choice(CHOICES)
			paddle_1, paddle_2 = list(PADDLE_X_INITIAL), list(PADDLE_Y_INITIAL)
		ball = [ball[0]+ball_x*SPEED_BALL, ball[1]+ball_y*SPEED_BALL]
		pygame.display.set_caption("PLAYER 1 : %d |----| PLAYER2 : %d" % (player_1, player_2))

	# DRAW IN THE AREA
	def draw():
		area.blit(BACKGROUND, (0, 0))
		pygame.draw.circle(area, WHITE, ball, RADIUS)
		pygame.draw.rect(area, BLACK, paddle_1)
		pygame.draw.rect(area, BLACK, paddle_2)

	# DISPLAY THE WELCOMING MESSAGE
	def startMessage(message):
		try:message=str(message)
		except Exception as error:print("[ERREUR] => %s" % error)
		else:
			if len(message) > 16:message = message
			else:message = "-"*16 
			intermediate2 = ""
			for k in range(len(message)):
				time.sleep(.2)
				intermediate2 += message[k]
				intermediate = intermediate2+" "*(len(message)-len(intermediate2))
				displayText = font.render(intermediate, True, RED)
				posText = list(displayText.get_rect())
				area.fill(BLACK)
				area.blit(displayText,((WIDTH-posText[2])//2, (HEIGHT-posText[3])//2))
				pygame.display.update()

	# ANIMATION
	def startAnimation(coefficient=2):
		try:coefficient = int(coefficient)
		except Exception as error:print("[ERROR] => %s" % error)
		else:
			if 1 <= coefficient <= 5:coefficient = coefficient
			else:coefficient = 2
			one, two = [0, 0, WIDTH//2, HEIGHT],[WIDTH//2, 0, WIDTH//2, HEIGHT]
			for k in range((WIDTH//2)//coefficient):
				one, two = [one[0], one[1], one[2]-coefficient, one[3]], [two[0]+coefficient, two[1], two[2]-coefficient, two[3]]
				draw()
				pygame.draw.rect(area, RED, one)
				pygame.draw.rect(area, RED, two)
				pygame.display.update()

	# Beginning => ANIMATIONS
	startMessage("This game was written by GhostManTech !")
	time.sleep(0.5)
	startAnimation(4)
	# MAIN GAME LOOP
	game = True
	while game:
		clock.tick(90)
		for event in pygame.event.get():
			if event.type == pygame.QUIT:game = False
		draw()
		pygame.display.update()
		move()
		gameplay()
	pygame.quit()