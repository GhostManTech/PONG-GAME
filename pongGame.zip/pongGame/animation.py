try:
	import pygame
	from pygame.locals import *
except ImportError:
	print("[ERROR] => %s" % error)

# DRAW PROGRESS BAR
def progressBar(WIDTH,HEIGHT,clock, font, area, outcome=1000,border=3,color1=(0,0,0),color2=(0,119,0),color3=(0,255,0),color4=(0,0,0),color5=(0,0,0)):
	try:
		WIDTH = int(WIDTH)
		HEIGHT = int(HEIGHT)
		outcome = int(outcome)
		color1 = tuple(color1)
		color2 = tuple(color2)
		color3 = tuple(color3)
		color4 = tuple(color4)
		color5 = tuple(color5)
		border = int(border)
	except Exception as error:
		print("[ERROR] => %s" % error)
	else:
		if 100 <= outcome <= 1000:
			outcome = outcome
		else:
			outcome=550
		if 2 <= border <= 5:
			border=border
		else:
			border = 3
		one = [(WIDTH-(WIDTH*(3/4)))//2,(HEIGHT-100)//2, int(WIDTH*(3/4)), 100]
		two = [(WIDTH-(WIDTH*(3/4)))//2,(HEIGHT-100)//2, 0, 100]
		three = [one[0]-border, one[1]-border, one[2]+border*2, one[3]+border*2]
		for k in range(1, outcome+1):
			clock.tick(60)
			intermediate = int((k*(WIDTH*(3/4)))/outcome)
			two = [two[0], two[1], intermediate,two[3]]
			text = font.render("%d%%"%(int(k/outcome*100)), True, color5)
			pos = (one[0]+(one[2]-text.get_width())//2, one[1]+(one[3]-text.get_height())//2)
			area.fill(color1)
			pygame.draw.rect(area,color4,three)
			pygame.draw.rect(area,color2,one)
			pygame.draw.rect(area,color3,two)
			area.blit(text,pos)
			pygame.display.update()

# DISPLAY THE WELCOMING MESSAGE
def message(WIDTH,HEIGHT,clock, area, font,message,color1=(255,255,255),color2=(0,0,0)):
	try:
		WIDTH = int(WIDTH)
		HEIGHT = int(HEIGHT)
		message = str(message)
		color1 = tuple(color1)
		color2 = tuple(color2)
	except Exception as error:
		print("[ERREUR] => %s" % error)
	else:
		if len(message) >= 5:
			message = message
		else:
			message = "-"*5 
		intermediate2 = ""
		for k in range(len(message)):
			clock.tick(60)
			intermediate2 += message[k]
			intermediate = intermediate2+" "*(len(message)-len(intermediate2))
			displayText = font.render(intermediate, True, color1)
			posText = list(displayText.get_rect())
			area.fill(color2)
			area.blit(displayText,((WIDTH-posText[2])//2, (HEIGHT-posText[3])//2))
			pygame.display.update()

# ANIMATION
def startAnimation(WIDTH,HEIGHT,function, area, coefficient=2,color=(0,0,0)):
	try:
		WIDTH = int(WIDTH)
		HEIGHT = int(HEIGHT)
		coefficient = int(coefficient)
		color = tuple(color)
	except Exception as error:
		print("[ERROR] => %s" % error)
	else:
		if 1 <= coefficient <= 5:
			coefficient = coefficient
		else:coefficient = 2
		one, two = [0, 0, WIDTH//2, HEIGHT],[WIDTH//2, 0, WIDTH//2, HEIGHT]
		for k in range((WIDTH//2)//coefficient):
			clock.tick(60)
			one, two = [one[0], one[1], one[2]-coefficient, one[3]], [two[0]+coefficient, two[1], two[2]-coefficient, two[3]]
			function()
			pygame.draw.rect(area, color, one)
			pygame.draw.rect(area, color, two)
			pygame.display.update()

def endAnimation(WIDTH, HEIGHT, function, area, coefficient=2,color=(0,0,0)):
	try:
		WIDTH = int(WIDTH)
		HEIGHT = int(HEIGHT)
		coefficient = int(coefficient)
		color = tuple(color)
	except Exception as error:
		print("[ERROR] => %s" % error)
	else:
		if 1 <= coefficient <= 5:
			coefficient = coefficient	
		else:
			coefficient = 2
		one, two = [0, 0, 0, HEIGHT],[WIDTH, 0, 0, HEIGHT]
		for k in range((WIDTH//2)//coefficient):
			one, two = [one[0], one[1], one[2]+coefficient, one[3]], [two[0]-coefficient, two[1], two[2]+coefficient, two[3]]
			function()
			pygame.draw.rect(area, color, one)
			pygame.draw.rect(area, color, two)
			pygame.display.update()